1. Erasing information hidden in the stego-file before it reaches the receiver, In case of Image steganography, hidden information can be erased by making all LSBS "0" or by randomizing the LSBs

2. It is difficult to identify if there is any hidden information in an image, audio or text 

3. There are many possible ways to find them, out of which two are listed below
      •	Histogram Analysis: The original image would typically have a smooth bell-shaped histogram in each colour channel (red, green, blue). Embedding data with LSB could subtly shift the peaks and valleys of the histogram, creating small bumps or dips visible through analysis tools like StegExpose.

      •	Colour Palette Analysis: LSB often leads to unnatural patterns in the used colour palette. For example, if the steganographic message uses mostly "1" bits, the image might have an unexpectedly high number of pixels with bright colours (high red, green, and blue values). Tools like StegSpy can analyse such anomalies

4. The process to run the sender reciever model is specified as follows:

The implementation of sender receiver model is done in python separately for audio steganography method
The sender code would send the stego-file which already has the hidden message in it to the receiver 
The receiver part of the code would receive the file and then decode the file after receiving it through the client and find the encoded message in it
To run the sender and receiver codes:
      •	If sender and receiver are in the same host device, then the “ip” (In the code) would be replaced by “localhost”
      •	If sender and receiver are in different host devices, then the “ip” (In the code) would be replaced by “%Receivers IP address%” 
