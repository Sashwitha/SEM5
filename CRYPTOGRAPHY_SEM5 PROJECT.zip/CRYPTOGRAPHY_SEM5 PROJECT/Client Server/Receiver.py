import socket
import base64
import wave
def decode_aud_data():

    nameoffile='audio_recv.wav'
    song = wave.open(nameoffile, mode='rb')
    nframes=song.getnframes()
    frames=song.readframes(nframes)
    frame_list=list(frames)
    frame_bytes=bytearray(frame_list)

    extracted = ""
    p=0
    for i in range(len(frame_bytes)):
        if(p==1):
            break
        res = bin(frame_bytes[i])[2:].zfill(8)
        if res[len(res)-2]==0:
            extracted+=res[len(res)-4]
        else:
            extracted+=res[len(res)-1]
    
        all_bytes = [ extracted[i: i+8] for i in range(0, len(extracted), 8) ]
        decoded_data = ""
        for byte in all_bytes:
            decoded_data += chr(int(byte, 2))
            if decoded_data[-5:] == "*^*^*":
                print("The Encoded data was :--",decoded_data[:-5])
                p=1
                break


host = 'localhost'  # Listen on all available network interfaces
port = 12345

# Create a socket object
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind the socket to the address and port
server_socket.bind((host, port))

# Listen for incoming connections (maximum of 5 queued connections)
server_socket.listen(5)
print(f"Server listening on {host}:{port}")

# Accept incoming connections
client_socket, client_address = server_socket.accept()
print(f"Connection from {client_address}")

# Receive the file content2
with open('audio_re.txt', 'wb') as file:
    while True:
        data = client_socket.recv(1024)
        if not data:
            break
        file.write(data)
with open('audio_re.txt', 'r') as text_file:
    audio_base64 = text_file.read()
decoded_audio_binary = base64.b64decode(audio_base64)
with open('audio_recv.wav', 'wb') as output_audio:
    output_audio.write(decoded_audio_binary)
print("File received successfully.")

decode_aud_data()

# Close the client socket
client_socket.close()
# Close the server socket
server_socket.close()
