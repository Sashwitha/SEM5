from tkinter import *
import socket
from tkinter import filedialog
import base64



filename = filedialog.askopenfilename()
with open(filename, 'rb') as image_file:
 image_binary = image_file.read()
image_base64 = base64.b64encode(image_binary)
with open('audio.txt', 'wb') as text_file:
 text_file.write(image_base64)

server_host = input("ip")  # Replace with the actual server's IP address
server_port = 12345

# Open the text file to send
with open('audio.txt', 'rb') as file:
    file_data = file.read()

# Create a socket object
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server
client_socket.connect((server_host, server_port))

# Send the file data to the server
client_socket.sendall(file_data)

print("File sent successfully.")