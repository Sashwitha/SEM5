import gradio as gr
from pydub import AudioSegment
import numpy as np
import librosa
import sqlite3
import soundfile as sf
from scipy.spatial.distance import cosine

# Initialize SQLite database with check_same_thread=False for multithreading support
conn = sqlite3.connect('bird_sounds.db', check_same_thread=False)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS bird_sounds (label TEXT, fft_feature BLOB, mfcc_feature BLOB)''')

FIXED_SAMPLE_RATE = 22050
FIXED_FFT_SIZE = 131072  # This should be larger than you expect to encounter
FIXED_NUM_MFCC_COEFFICIENTS = 13

def train(audio_file_list, label_inputs):
    # Process label inputs correctly, assuming they are comma-separated
    input_labels = [label.strip() for label in label_inputs.split(',')]

    for i, audio_file in enumerate(audio_file_list):
        label = input_labels[i] if i < len(input_labels) else "Unknown"
        try:
            # Use Pydub to open and process the MP3 file
            audio_segment = AudioSegment.from_file(audio_file.name)
            # Convert Pydub audio segment to NumPy array
            samples = np.array(audio_segment.get_array_of_samples(), dtype=np.float32)
            if audio_segment.channels == 2:  # If stereo, take only the first channel
                samples = samples.reshape((-1, 2))[:, 0]
            sr = audio_segment.frame_rate

            # Resample to FIXED_SAMPLE_RATE if necessary
            if sr != FIXED_SAMPLE_RATE:
                samples = librosa.resample(y=samples, orig_sr=sr, target_sr=FIXED_SAMPLE_RATE)
                sr = FIXED_SAMPLE_RATE

            # Pad or truncate to FIXED_FFT_SIZE
            if len(samples) < FIXED_FFT_SIZE:
                padded_samples = np.pad(samples, (0, FIXED_FFT_SIZE - len(samples)), mode='constant')
            else:
                padded_samples = samples[:FIXED_FFT_SIZE]

            # Apply FFT and extract MFCCs
            fft_result = np.abs(np.fft.rfft(padded_samples, n=FIXED_FFT_SIZE))
            fft_result = fft_result[:FIXED_FFT_SIZE // 2 + 1]
            mfccs = librosa.feature.mfcc(y=padded_samples, sr=FIXED_SAMPLE_RATE, n_mfcc=FIXED_NUM_MFCC_COEFFICIENTS)

            # Insert features and label into SQLite database
            c.execute("INSERT INTO bird_sounds (label, fft_feature, mfcc_feature) VALUES (?, ?, ?)",
                      (label, fft_result.tobytes(), mfccs.tobytes()))

        except Exception as e:
            return f"Error processing the audio file: {e}"

    conn.commit()
    return "Training complete!"


def evaluate(audio_file):
    c.execute("SELECT label, fft_feature, mfcc_feature FROM bird_sounds")
    data = c.fetchall()
    labels, fft_features, mfcc_features = zip(*data)

    new_audio = AudioSegment.from_file(audio_file.name)
    new_audio_array = np.array(new_audio.get_array_of_samples(), dtype=np.float32)

    if new_audio.channels == 2:  # If stereo, take only the first channel
        new_audio_array = new_audio_array.reshape((-1, 2))[:, 0]

    # Resample to FIXED_SAMPLE_RATE if necessary
    if new_audio.frame_rate != FIXED_SAMPLE_RATE:
        new_audio_array = librosa.resample(y=new_audio_array, orig_sr=new_audio.frame_rate, target_sr=FIXED_SAMPLE_RATE)

    # Pad or truncate to FIXED_FFT_SIZE
    if len(new_audio_array) < FIXED_FFT_SIZE:
        padded_audio_array = np.pad(new_audio_array, (0, FIXED_FFT_SIZE - len(new_audio_array)), mode='constant')
    else:
        padded_audio_array = new_audio_array[:FIXED_FFT_SIZE]

    # Apply FFT and extract MFCCs
    new_fft_result = np.abs(np.fft.rfft(padded_audio_array, n=FIXED_FFT_SIZE))
    new_fft_length = FIXED_FFT_SIZE // 2 + 1
    new_fft_result = new_fft_result[:new_fft_length]
    new_mfccs = librosa.feature.mfcc(y=padded_audio_array, sr=FIXED_SAMPLE_RATE, n_mfcc=FIXED_NUM_MFCC_COEFFICIENTS)

    similarity_scores = []
    for label, fft_feature, mfcc_feature in data:
        # Ensure FFT feature is the correct length (FIXED_FFT_SIZE // 2 + 1 due to rfft)
        existing_fft = np.frombuffer(fft_feature, dtype=np.float32)
        if len(existing_fft) != new_fft_length:
            existing_fft = np.pad(existing_fft, (0, max(0, new_fft_length - len(existing_fft))), mode='constant')
            existing_fft = existing_fft[:new_fft_length]  # Truncate or pad to the new fft length

        fft_similarity = 1 - cosine(existing_fft, new_fft_result)

        # Ensure MFCC feature has the correct shape
        existing_mfcc = np.frombuffer(mfcc_feature, dtype=np.float32).reshape(-1, FIXED_NUM_MFCC_COEFFICIENTS)
        mfcc_similarity = 1 - cosine(existing_mfcc.ravel(), new_mfccs.ravel())

        overall_similarity = (fft_similarity + mfcc_similarity) / 2
        similarity_scores.append((label, overall_similarity))

    similarity_scores.sort(key=lambda x: x[1], reverse=True)

    results = "\nPrediction Results:\n"
    for label, score in similarity_scores:
        results += f"{label}: Similarity Score = {score * 100:.2f}%\n"

    return results


train_interface = gr.Interface(
    fn=train,
    inputs=[
        gr.Files(label="Audio Files (mp3)"),
        gr.Textbox(label="Labels (comma-separated)")
    ],
    outputs="text"  # This enables the progress bar for the function
)

eval_interface = gr.Interface(
    fn=evaluate,
    inputs=gr.File(label="Audio File (mp3)"),
    outputs="text"
)

demo = gr.TabbedInterface(
    [train_interface, eval_interface],
    ["Train", "Evaluate"],
    title="Bird Sound Classification"
)

demo.launch()